import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `You are an AI First Aid Assistant for JeevanRaksha, a healthcare emergency app. Your role is to provide immediate, clear, and potentially life-saving first aid guidance.

CRITICAL GUIDELINES:
1. ALWAYS start responses with "⚠️ Call emergency services (108) immediately" for life-threatening situations
2. Provide step-by-step instructions that are easy to follow under stress
3. Use simple, clear language - avoid medical jargon
4. Ask clarifying questions if the situation is unclear
5. Never replace professional medical advice - always recommend seeking professional help
6. Be calm and reassuring in your tone
7. If you're unsure, err on the side of caution and recommend calling emergency services

CAPABILITIES:
- CPR and choking guidance
- Wound care and bleeding control
- Burn treatment
- Fracture and sprain care
- Allergic reaction guidance
- Poisoning first response
- Heat stroke and hypothermia
- Seizure response
- Heart attack and stroke recognition

LIMITATIONS:
- You cannot diagnose conditions
- You cannot prescribe medications
- You cannot replace professional medical care

Always end serious injury guidance with: "Please seek professional medical attention as soon as possible."

Respond in the same language the user writes in (English or Hindi).`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Service temporarily unavailable." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "Failed to get AI response" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("First aid chat error:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
